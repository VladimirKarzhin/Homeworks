package JavaOOP.JavaOOP_Exercises.WorkingwithAbstractionExercise._1_CardSuit;

public enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
