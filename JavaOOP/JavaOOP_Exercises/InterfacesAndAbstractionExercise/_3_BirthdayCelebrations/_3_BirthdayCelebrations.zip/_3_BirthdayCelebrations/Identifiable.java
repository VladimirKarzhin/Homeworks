package _3_BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
