package _3_BirthdayCelebrations;

public class Main {
    public static void main(String[] args) {
        
    }
}
