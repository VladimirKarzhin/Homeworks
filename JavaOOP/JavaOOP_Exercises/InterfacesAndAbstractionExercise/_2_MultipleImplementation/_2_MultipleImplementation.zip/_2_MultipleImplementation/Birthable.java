package _2_MultipleImplementation;

public interface Birthable {
    String getBirthDate();
}
