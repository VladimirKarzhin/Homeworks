package _2_MultipleImplementation;

public interface Person {
    String getName();
    int getAge();

}
