package _2_MultipleImplementation;

public interface Identifiable {
    String getId();
}
