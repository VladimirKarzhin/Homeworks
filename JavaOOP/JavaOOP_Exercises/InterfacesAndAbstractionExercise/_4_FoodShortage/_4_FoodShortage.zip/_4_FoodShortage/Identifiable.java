package _4_FoodShortage;

public interface Identifiable {
    String getId();
}
