package _4_FoodShortage;

public class Main {
    public static void main(String[] args) {

    }
}
