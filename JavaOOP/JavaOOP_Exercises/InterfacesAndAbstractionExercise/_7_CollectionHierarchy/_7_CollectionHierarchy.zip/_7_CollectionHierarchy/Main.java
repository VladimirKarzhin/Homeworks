package _7_CollectionHierarchy;

public class Main {
    public static void main(String[] args) {
        
    }
}
