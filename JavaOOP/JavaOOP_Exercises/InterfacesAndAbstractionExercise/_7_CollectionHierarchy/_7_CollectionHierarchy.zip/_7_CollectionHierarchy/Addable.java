package _7_CollectionHierarchy;

public interface Addable {
    int add(String name);
}
