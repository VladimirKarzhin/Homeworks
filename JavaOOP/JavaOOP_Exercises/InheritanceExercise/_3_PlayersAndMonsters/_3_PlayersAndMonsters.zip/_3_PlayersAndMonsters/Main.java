package _3_PlayersAndMonsters;

public class Main {
}
