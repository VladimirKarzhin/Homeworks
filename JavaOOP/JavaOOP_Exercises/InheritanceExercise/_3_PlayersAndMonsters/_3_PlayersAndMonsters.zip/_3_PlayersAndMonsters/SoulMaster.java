package _3_PlayersAndMonsters;

public class SoulMaster extends DarkWizard {
    public SoulMaster(String username, int level) {
        super(username, level);
    }
}
