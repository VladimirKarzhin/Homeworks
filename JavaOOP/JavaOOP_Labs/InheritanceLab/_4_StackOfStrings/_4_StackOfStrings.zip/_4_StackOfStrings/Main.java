package _4_StackOfStrings;

public class Main {
}
